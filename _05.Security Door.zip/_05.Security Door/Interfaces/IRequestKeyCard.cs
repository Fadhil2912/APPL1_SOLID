﻿namespace _05.Security_Door.Interfaces
{
    public interface IRequestKeyCard
    {
        string RequestKeyCard();
    }
}
