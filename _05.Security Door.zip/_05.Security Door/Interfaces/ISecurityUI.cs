﻿using _05.Security_Door.Interfaces;

namespace _05.Security_Door
{
    public interface ISecurityUI : IRequestKeyCard, IRequestPinCode
    {
    }
}