﻿namespace _02.Graphic_Editor
{
    public class Rectangle : IShape
    {
        public string Drow()
        {
            return "I'm Rectangle";
        }
    }
}