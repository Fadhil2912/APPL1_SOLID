﻿namespace _04.Recharge
{
    public interface ISleeper
    {
        void Sleep();
    }
}